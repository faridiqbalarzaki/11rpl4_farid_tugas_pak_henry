<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$kode= $_POST['kodeBarang'];
$nama= $_POST['namaBarang'];
$satuan= $_POST['satuanBarang'];
$stok= $_POST['stokBarang'];
$harga= $_POST['hargaBarang'];
 
// update data ke database
mysqli_query($koneksi,"update tb_toko set kodeBarang='$kode', namaBarang='$nama', satuanBarang='$satuan',stokBarang='$stok' where hargaBarang='$harga'");
 
// mengalihkan halaman kembali ke index.php
header("location:index.php");
 
?>

